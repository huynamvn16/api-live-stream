var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'huynamvn1606',
applicationName: 'live-stream',
appUid: 'yJMRb5YfpRvbxtlmnF',
tenantUid: '4Hg28H6m9PkHSsB4Xr',
deploymentUid: 'be3adeb0-3bce-4dfa-bcbb-8792038d3e2e',
serviceName: 'live-stream',
stageName: 'dev'})
const handlerWrapperArgs = { functionName: 'live-stream-dev-app', timeout: 6}
try {
  const userHandler = require('./app.js')
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
